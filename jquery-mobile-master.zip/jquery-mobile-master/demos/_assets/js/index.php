<?php
$type = 'text/javascript';
$files = array(
	'jqm-demos.js',
	'syntaxhighlighter.js',
	'view-source.js',
	'h2widget.js'
);

require_once('../../../combine.php');
