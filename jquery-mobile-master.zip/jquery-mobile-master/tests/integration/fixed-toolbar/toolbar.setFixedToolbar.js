define( [ "jquery" ], function( $ ) {
	$.fn.fixedtoolbar = $.fn.toolbar;
} );
